package com.samsung.biz.users;

public class BlockTest {
	
	
	static {
		System.out.println("static{}");
	}
	
	{
		System.out.println("{}");
	}
	
	public BlockTest(){
		System.out.println("생성자");
	}
	
	public static void main(String[] args) {
		System.out.println("BlockTest t = new BlockTest();");
		BlockTest t = new BlockTest();
		
		System.out.println("BlockTest t2 = new BlockTest();");
		BlockTest t2 = new BlockTest();
	}

}
